# To Compile

- Open .sln in Visual Studio 2017 or later
- Ensure 'Wordulator' is default app
- compile & run

## Requirements:
- working nuget to restore packages if needed
- .NET Framework 4.7.2 or later.

## Usage
- Select a file, either epub (not supported fully) or text file, using the provided "Choose file" button
- Select the "Process Book" button to start processing
- All results will be displayed in the text box below.